Jonah Katz and Zachary Chenet 

Ensure there is a file called input.txt, which contains the PL0 program, is in the same directory as the rest of the source files. All the C files and C Header files need to be in the same directory as CompileDriver.c. To run the program, simply compile the CompileDriver.c like so:

	`gcc CompileDriver.c -o compileDriver`

And then run it by doing:

	`./compileDriver`

You can run it with any or all of the flags -v, -a, and -l:

	`./compileDriver -v -a -l`	

